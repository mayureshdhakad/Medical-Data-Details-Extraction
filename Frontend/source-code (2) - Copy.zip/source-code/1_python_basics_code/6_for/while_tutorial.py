
n = 0

while n <= 10:
    print(n)
    n += 1